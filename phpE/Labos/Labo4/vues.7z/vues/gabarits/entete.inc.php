<!-- 
	Description : Entête pour le site la ligue de soccer métropolitaine
	Session     : H2020 (défini au Labo4)
	Auteurs     : Walid Gharbi
-->
<div class="entete">
	<img class="gauche" src="../images/logo_ligue.png" alt="logo" height="80" />
	<h1 class="droite">Ligue de soccer métropolitaine</h1>
</div>