<!-- 
	Description : Pied de page pour le site la ligue de soccer métropolitaine
	Session     : H2020 (défini au Labo4)
	Auteurs     : Walid Gharbi
-->
<div class="pied">
		<a class="gauche" id="validateur" href="https://validator.w3.org/#validate_by_upload" target="_blank">
			<img src="../images/w3c.png" alt="validation" height="40" />
		</a>
		<h3 class="gauche indentation">
			Validation
		</h3>
		<h3 class="droite">
			Fait par Walid Gharbi (Hiver 2020)
		</h3>
	</div>